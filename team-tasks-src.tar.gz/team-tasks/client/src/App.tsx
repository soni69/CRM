import { useEffect, useState } from 'react'
import { api } from './lib/api'
import type { User } from './lib/types'
import { AuthPage } from './components/AuthPage'
import { TaskBoard } from './components/TaskBoard'
import { ToastProvider } from './components/Toast'
import { useTheme } from './lib/useTheme'

export default function App() {
  useTheme()
  const [user, setUser] = useState<User | null | undefined>(undefined)

  useEffect(() => {
    api
      .me()
      .then(({ user }) => setUser(user))
      .catch(() => setUser(null))
  }, [])

  if (user === undefined) {
    return (
      <div className="flex min-h-dvh items-center justify-center">
        <div className="size-8 animate-spin rounded-full border-4 border-indigo-200 border-t-indigo-600" />
      </div>
    )
  }

  return (
    <ToastProvider>
      {user ? (
        <TaskBoard
          user={user}
          onLogout={async () => {
            await api.logout().catch(() => {})
            setUser(null)
          }}
        />
      ) : (
        <AuthPage onAuth={setUser} />
      )}
    </ToastProvider>
  )
}
