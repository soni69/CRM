import { useState } from 'react'
import { Modal, btn } from './Modal'

interface Props {
  title: string
  text: string
  confirmLabel: string
  onConfirm: () => Promise<void>
  onClose: () => void
}

export function ConfirmDialog({ title, text, confirmLabel, onConfirm, onClose }: Props) {
  const [busy, setBusy] = useState(false)
  return (
    <Modal
      title={title}
      onClose={onClose}
      size="sm"
      footer={
        <>
          <button className={btn.secondary} onClick={onClose}>
            Отмена
          </button>
          <button
            className={btn.danger}
            disabled={busy}
            onClick={async () => {
              setBusy(true)
              try {
                await onConfirm()
              } finally {
                setBusy(false)
              }
            }}
          >
            {confirmLabel}
          </button>
        </>
      }
    >
      <p className="text-sm text-slate-600 dark:text-slate-300">{text}</p>
    </Modal>
  )
}
