import { useEffect, useRef, useState } from 'react'
import { Check, ChevronDown } from 'lucide-react'
import { STATUSES, statusMeta, type Status } from '../lib/types'

export function StatusMenu({ status, onChange }: { status: Status; onChange: (s: Status) => void }) {
  const [open, setOpen] = useState(false)
  const ref = useRef<HTMLDivElement>(null)
  const meta = statusMeta(status)

  useEffect(() => {
    if (!open) return
    const close = (e: MouseEvent) => !ref.current?.contains(e.target as Node) && setOpen(false)
    document.addEventListener('mousedown', close)
    return () => document.removeEventListener('mousedown', close)
  }, [open])

  return (
    <div ref={ref} className="relative" onClick={(e) => e.stopPropagation()}>
      <button
        type="button"
        aria-label="Изменить статус"
        onClick={() => setOpen((o) => !o)}
        className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium ring-1 ring-inset transition hover:brightness-95 ${meta.badge}`}
      >
        <span className={`size-1.5 rounded-full ${meta.dot}`} />
        {meta.label}
        <ChevronDown className="size-3 opacity-60" />
      </button>
      {open && (
        <div className="animate-fade-in absolute left-0 z-20 mt-1 w-40 overflow-hidden rounded-xl bg-white p-1 shadow-lg ring-1 ring-slate-200 dark:bg-slate-800 dark:ring-slate-700">
          {STATUSES.map((s) => (
            <button
              key={s.value}
              type="button"
              onClick={() => {
                setOpen(false)
                if (s.value !== status) onChange(s.value)
              }}
              className="flex w-full items-center gap-2 rounded-lg px-2.5 py-2 text-left text-sm hover:bg-slate-100 dark:hover:bg-slate-700"
            >
              <span className={`size-2 rounded-full ${s.dot}`} />
              <span className="flex-1">{s.label}</span>
              {s.value === status && <Check className="size-4 text-indigo-600 dark:text-indigo-400" />}
            </button>
          ))}
        </div>
      )}
    </div>
  )
}
