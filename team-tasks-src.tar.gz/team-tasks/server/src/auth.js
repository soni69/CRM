import jwt from 'jsonwebtoken';
import crypto from 'node:crypto';
import { one } from './db.js';

const JWT_SECRET = process.env.JWT_SECRET || crypto.randomBytes(32).toString('hex');
if (!process.env.JWT_SECRET) {
  console.warn('JWT_SECRET is not set: using a random secret, sessions will reset on restart');
}

export const COOKIE_NAME = 'tt_session';
const MAX_AGE_MS = 1000 * 60 * 60 * 24 * 30;

export function setSession(res, userId) {
  const token = jwt.sign({ sub: userId }, JWT_SECRET, { expiresIn: MAX_AGE_MS / 1000 });
  res.cookie(COOKIE_NAME, token, {
    httpOnly: true,
    sameSite: 'lax',
    secure: res.req.secure,
    maxAge: MAX_AGE_MS,
    path: '/',
  });
}

export function clearSession(res) {
  res.clearCookie(COOKIE_NAME, { path: '/' });
}

export async function requireAuth(req, res, next) {
  const token = req.cookies?.[COOKIE_NAME];
  if (!token) return res.status(401).json({ error: 'Требуется авторизация' });
  let payload;
  try {
    payload = jwt.verify(token, JWT_SECRET);
  } catch {
    return res.status(401).json({ error: 'Сессия истекла, войдите снова' });
  }
  const user = await one('SELECT id, name, email, created_at FROM users WHERE id = $1', [payload.sub]);
  if (!user) return res.status(401).json({ error: 'Пользователь не найден' });
  req.user = user;
  next();
}
