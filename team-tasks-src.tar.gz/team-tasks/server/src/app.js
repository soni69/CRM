import express from 'express';
import cookieParser from 'cookie-parser';
import bcrypt from 'bcryptjs';
import { z } from 'zod';
import { ensureSchema, one, query } from './db.js';
import { setSession, clearSession, requireAuth } from './auth.js';
import { seedDemo } from './seed.js';

export const app = express();
app.set('trust proxy', 1);
app.use(express.json({ limit: '100kb' }));
app.use(cookieParser());
app.use('/api', async (_req, _res, next) => {
  await ensureSchema(seedDemo);
  next();
});

const STATUSES = ['new', 'in_progress', 'done'];
const PRIORITIES = ['low', 'medium', 'high'];

function parse(schema, data, res) {
  const result = schema.safeParse(data);
  if (!result.success) {
    res.status(400).json({ error: result.error.issues[0]?.message || 'Некорректные данные' });
    return null;
  }
  return result.data;
}

// ---------- Auth ----------
const registerSchema = z.object({
  name: z.string().trim().min(2, 'Имя должно быть не короче 2 символов').max(60, 'Имя слишком длинное'),
  email: z.email('Некорректный email').trim().toLowerCase(),
  password: z.string().min(6, 'Пароль должен быть не короче 6 символов').max(100),
});
const loginSchema = z.object({
  email: z.string().trim().toLowerCase().min(1, 'Введите email'),
  password: z.string().min(1, 'Введите пароль'),
});

app.post('/api/auth/register', async (req, res) => {
  const data = parse(registerSchema, req.body, res);
  if (!data) return;
  if (await one('SELECT 1 FROM users WHERE email = $1', [data.email])) {
    return res.status(409).json({ error: 'Пользователь с таким email уже существует' });
  }
  const hash = await bcrypt.hash(data.password, 10);
  const user = await one('INSERT INTO users (name, email, password_hash) VALUES ($1, $2, $3) RETURNING id, name, email', [
    data.name,
    data.email,
    hash,
  ]);
  setSession(res, user.id);
  res.status(201).json({ user });
});

app.post('/api/auth/login', async (req, res) => {
  const data = parse(loginSchema, req.body, res);
  if (!data) return;
  const user = await one('SELECT * FROM users WHERE email = $1', [data.email]);
  if (!user || !(await bcrypt.compare(data.password, user.password_hash))) {
    return res.status(401).json({ error: 'Неверный email или пароль' });
  }
  setSession(res, user.id);
  res.json({ user: { id: user.id, name: user.name, email: user.email } });
});

app.post('/api/auth/logout', (_req, res) => {
  clearSession(res);
  res.json({ ok: true });
});

app.get('/api/auth/me', requireAuth, (req, res) => {
  res.json({ user: req.user });
});

// ---------- Users ----------
app.get('/api/users', requireAuth, async (_req, res) => {
  const { rows } = await query('SELECT id, name, email FROM users ORDER BY lower(name)');
  res.json({ users: rows });
});

// ---------- Tasks ----------
const TASK_SELECT = `
  SELECT t.*, a.name AS assignee_name, c.name AS creator_name
  FROM tasks t
  LEFT JOIN users a ON a.id = t.assignee_id
  LEFT JOIN users c ON c.id = t.creator_id
`;

const dueDate = z
  .string()
  .regex(/^\d{4}-\d{2}-\d{2}$/, 'Некорректная дата')
  .nullable()
  .or(z.literal('').transform(() => null));

const taskSchema = z.object({
  title: z.string().trim().min(1, 'Введите название задачи').max(200, 'Название слишком длинное'),
  description: z.string().trim().max(5000, 'Описание слишком длинное').default(''),
  status: z.enum(STATUSES).default('new'),
  priority: z.enum(PRIORITIES).default('medium'),
  due_date: dueDate.optional().default(null),
  assignee_id: z.number().int().positive().nullable().optional().default(null),
});
const taskPatchSchema = z
  .object({
    title: taskSchema.shape.title,
    description: z.string().trim().max(5000, 'Описание слишком длинное'),
    status: z.enum(STATUSES),
    priority: z.enum(PRIORITIES),
    due_date: dueDate,
    assignee_id: z.number().int().positive().nullable(),
  })
  .partial();

const assigneeExists = async (id) => id == null || !!(await one('SELECT 1 FROM users WHERE id = $1', [id]));
const getTask = (id) => one(`${TASK_SELECT} WHERE t.id = $1`, [id]);
const taskId = (req) => (/^\d+$/.test(req.params.id) ? Number(req.params.id) : null);

app.get('/api/tasks', requireAuth, async (req, res) => {
  const where = [];
  const params = [];
  const add = (v) => {
    params.push(v);
    return `$${params.length}`;
  };
  const { q, status, assignee, sort } = req.query;
  if (typeof q === 'string' && q.trim()) {
    const p = add(`%${q.trim().replace(/[\\%_]/g, (c) => '\\' + c)}%`);
    where.push(`(t.title ILIKE ${p} OR t.description ILIKE ${p})`);
  }
  if (typeof status === 'string' && STATUSES.includes(status)) where.push(`t.status = ${add(status)}`);
  if (assignee === 'me') where.push(`t.assignee_id = ${add(req.user.id)}`);
  else if (assignee === 'none') where.push('t.assignee_id IS NULL');
  else if (typeof assignee === 'string' && /^\d+$/.test(assignee)) where.push(`t.assignee_id = ${add(Number(assignee))}`);

  const orderBy =
    {
      updated: 't.updated_at DESC',
      created: 't.created_at DESC',
      due: 't.due_date ASC NULLS LAST',
      priority: "CASE t.priority WHEN 'high' THEN 0 WHEN 'medium' THEN 1 ELSE 2 END, t.updated_at DESC",
    }[sort] || 't.updated_at DESC';
  const sql = `${TASK_SELECT} ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY ${orderBy}, t.id DESC`;
  const { rows } = await query(sql, params);
  res.json({ tasks: rows });
});

app.post('/api/tasks', requireAuth, async (req, res) => {
  const data = parse(taskSchema, req.body, res);
  if (!data) return;
  if (!(await assigneeExists(data.assignee_id))) return res.status(400).json({ error: 'Ответственный не найден' });
  const { id } = await one(
    `INSERT INTO tasks (title, description, status, priority, due_date, assignee_id, creator_id)
     VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING id`,
    [data.title, data.description, data.status, data.priority, data.due_date, data.assignee_id, req.user.id],
  );
  res.status(201).json({ task: await getTask(id) });
});

app.patch('/api/tasks/:id', requireAuth, async (req, res) => {
  const id = taskId(req);
  if (!id || !(await getTask(id))) return res.status(404).json({ error: 'Задача не найдена' });
  const data = parse(taskPatchSchema, req.body, res);
  if (!data) return;
  if ('assignee_id' in data && !(await assigneeExists(data.assignee_id))) {
    return res.status(400).json({ error: 'Ответственный не найден' });
  }
  const keys = Object.keys(data);
  if (keys.length) {
    const sets = keys.map((k, i) => `${k} = $${i + 2}`).join(', ');
    await query(`UPDATE tasks SET ${sets}, updated_at = now() WHERE id = $1`, [id, ...keys.map((k) => data[k])]);
  }
  res.json({ task: await getTask(id) });
});

app.delete('/api/tasks/:id', requireAuth, async (req, res) => {
  const id = taskId(req);
  const { rowCount } = id ? await query('DELETE FROM tasks WHERE id = $1', [id]) : { rowCount: 0 };
  if (!rowCount) return res.status(404).json({ error: 'Задача не найдена' });
  res.json({ ok: true });
});

app.use('/api', (_req, res) => res.status(404).json({ error: 'Not found' }));

export function handleErrors(app) {
  app.use((err, _req, res, _next) => {
    console.error(err);
    res.status(500).json({ error: 'Внутренняя ошибка сервера' });
  });
}
