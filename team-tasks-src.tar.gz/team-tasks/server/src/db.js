import pg from 'pg';

pg.types.setTypeParser(1082, (v) => v);

const connectionString =
  process.env.DATABASE_URL || process.env.POSTGRES_URL || 'postgres://postgres:pg@localhost:5432/teamtasks';

export const pool = new pg.Pool({
  connectionString,
  max: process.env.VERCEL ? 3 : 10,
  ssl: /localhost|127\.0\.0\.1|@db:/.test(connectionString) ? false : { rejectUnauthorized: false },
});

export const query = (text, params) => pool.query(text, params);
export const one = async (text, params) => (await pool.query(text, params)).rows[0];

const SCHEMA = `
  CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
  );

  CREATE TABLE IF NOT EXISTS tasks (
    id SERIAL PRIMARY KEY,
    title TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL DEFAULT 'new' CHECK (status IN ('new', 'in_progress', 'done')),
    priority TEXT NOT NULL DEFAULT 'medium' CHECK (priority IN ('low', 'medium', 'high')),
    due_date DATE,
    assignee_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
    creator_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
  );

  CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(status);
  CREATE INDEX IF NOT EXISTS idx_tasks_assignee ON tasks(assignee_id);
`;

let ready;
export function ensureSchema(onCreated) {
  ready ??= (async () => {
    await pool.query(SCHEMA);
    await onCreated?.();
  })().catch((err) => {
    ready = undefined;
    throw err;
  });
  return ready;
}
