import { CalendarDays, Flag, Pencil, Trash2 } from 'lucide-react'
import { Avatar } from './Avatar'
import { StatusMenu } from './StatusMenu'
import { priorityMeta, type Status, type Task } from '../lib/types'
import { formatDue } from '../lib/format'

interface Props {
  task: Task
  onOpen: () => void
  onDelete: () => void
  onStatus: (s: Status) => void
  draggable?: boolean
}

export function TaskCard({ task, onOpen, onDelete, onStatus, draggable }: Props) {
  const due = formatDue(task.due_date)
  const prio = priorityMeta(task.priority)
  const done = task.status === 'done'

  return (
    <article
      draggable={draggable}
      onDragStart={(e) => {
        e.dataTransfer.setData('text/plain', String(task.id))
        e.dataTransfer.effectAllowed = 'move'
      }}
      onClick={onOpen}
      className="group cursor-pointer rounded-2xl bg-white p-4 shadow-sm ring-1 ring-slate-200/70 transition hover:-translate-y-0.5 hover:shadow-md hover:ring-indigo-200 dark:bg-slate-900 dark:ring-slate-800 dark:hover:ring-indigo-500/40"
    >
      <div className="flex items-start justify-between gap-2">
        <h3 className={`text-[15px] leading-snug font-semibold break-words ${done ? 'text-slate-400 line-through decoration-slate-300 dark:text-slate-500' : ''}`}>
          {task.title}
        </h3>
        <div className="-mt-1 -mr-1 flex shrink-0 opacity-100 transition sm:opacity-0 sm:group-hover:opacity-100">
          <button
            aria-label="Редактировать"
            onClick={(e) => {
              e.stopPropagation()
              onOpen()
            }}
            className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700 dark:hover:bg-slate-800 dark:hover:text-slate-200"
          >
            <Pencil className="size-4" />
          </button>
          <button
            aria-label="Удалить"
            onClick={(e) => {
              e.stopPropagation()
              onDelete()
            }}
            className="rounded-lg p-1.5 text-slate-400 hover:bg-rose-50 hover:text-rose-600 dark:hover:bg-rose-500/10"
          >
            <Trash2 className="size-4" />
          </button>
        </div>
      </div>

      {task.description && <p className="mt-1.5 line-clamp-2 text-sm text-slate-500 dark:text-slate-400">{task.description}</p>}

      <div className="mt-3 flex flex-wrap items-center gap-x-3 gap-y-2">
        <StatusMenu status={task.status} onChange={onStatus} />
        <span className={`inline-flex items-center gap-1 text-xs font-medium ${prio.className}`} title="Приоритет">
          <Flag className="size-3.5" />
          {prio.label}
        </span>
        {due && (
          <span
            className={`inline-flex items-center gap-1 text-xs font-medium ${
              due.overdue && !done ? 'text-rose-600 dark:text-rose-400' : due.soon && !done ? 'text-amber-600 dark:text-amber-400' : 'text-slate-500 dark:text-slate-400'
            }`}
            title="Срок"
          >
            <CalendarDays className="size-3.5" />
            {due.label}
          </span>
        )}
        <span className="ml-auto flex min-w-0 items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400">
          <span className="truncate">{task.assignee_name ?? 'Не назначен'}</span>
          <Avatar id={task.assignee_id} name={task.assignee_name} size="sm" />
        </span>
      </div>
    </article>
  )
}
