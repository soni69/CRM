import express from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import { app, handleErrors } from './app.js';

const clientDist = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../client/dist');
if (fs.existsSync(clientDist)) {
  app.use(express.static(clientDist, { index: false, maxAge: '1h' }));
  app.get(/.*/, (_req, res) => res.sendFile(path.join(clientDist, 'index.html')));
}
handleErrors(app);

const port = Number(process.env.PORT) || 3000;
app.listen(port, () => console.log(`Team Tasks running on http://localhost:${port}`));
