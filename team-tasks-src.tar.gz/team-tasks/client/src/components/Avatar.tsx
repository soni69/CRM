import { avatarColor, initials } from '../lib/format'

export function Avatar({ id, name, size = 'md' }: { id: number | null; name: string | null; size?: 'sm' | 'md' }) {
  const s = size === 'sm' ? 'size-6 text-[10px]' : 'size-8 text-xs'
  return (
    <span
      title={name ?? 'Не назначен'}
      className={`${s} ${avatarColor(id)} inline-flex shrink-0 items-center justify-center rounded-full font-semibold text-white ring-2 ring-white dark:ring-slate-900`}
    >
      {id == null ? '—' : initials(name)}
    </span>
  )
}
