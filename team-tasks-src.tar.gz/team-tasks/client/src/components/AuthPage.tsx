import { useState, type FormEvent } from 'react'
import { CheckCircle2, Columns3, Search, Users } from 'lucide-react'
import { api } from '../lib/api'
import type { User } from '../lib/types'
import { btn, inputCls } from './Modal'
import { Logo } from './Logo'

export function AuthPage({ onAuth }: { onAuth: (u: User) => void }) {
  const [mode, setMode] = useState<'login' | 'register'>('login')
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  const submit = async (e: FormEvent) => {
    e.preventDefault()
    setBusy(true)
    setError('')
    try {
      const { user } = mode === 'login' ? await api.login(email, password) : await api.register(name, email, password)
      onAuth(user)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Ошибка')
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="grid min-h-dvh lg:grid-cols-2">
      <aside className="relative hidden overflow-hidden bg-gradient-to-br from-indigo-600 via-indigo-700 to-violet-800 p-12 text-white lg:flex lg:flex-col">
        <div className="absolute -top-24 -right-24 size-96 rounded-full bg-white/10 blur-3xl" />
        <div className="absolute -bottom-32 -left-16 size-96 rounded-full bg-violet-400/20 blur-3xl" />
        <Logo light />
        <div className="relative my-auto max-w-md">
          <h1 className="text-4xl leading-tight font-bold">Все задачи команды — в одном месте</h1>
          <p className="mt-4 text-lg text-indigo-100">Создавайте задачи, назначайте ответственных и отслеживайте прогресс в реальном времени.</p>
          <ul className="mt-10 space-y-4 text-indigo-50">
            {[
              [Columns3, 'Канбан-доска и список задач'],
              [Users, 'Назначение ответственных'],
              [Search, 'Быстрый поиск и фильтры'],
              [CheckCircle2, 'Статусы: Новая, В работе, Завершена'],
            ].map(([Icon, text], i) => {
              const I = Icon as typeof Users
              return (
                <li key={i} className="flex items-center gap-3">
                  <span className="rounded-lg bg-white/15 p-2">
                    <I className="size-5" />
                  </span>
                  {text as string}
                </li>
              )
            })}
          </ul>
        </div>
      </aside>

      <main className="flex items-center justify-center px-5 py-10">
        <div className="w-full max-w-sm">
          <div className="mb-8 lg:hidden">
            <Logo />
          </div>
          <h2 className="text-2xl font-bold">{mode === 'login' ? 'С возвращением!' : 'Создать аккаунт'}</h2>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
            {mode === 'login' ? 'Войдите, чтобы продолжить работу с задачами' : 'Присоединяйтесь к команде за минуту'}
          </p>

          <div className="mt-6 grid grid-cols-2 gap-1 rounded-xl bg-slate-100 p-1 dark:bg-slate-800">
            {(['login', 'register'] as const).map((m) => (
              <button
                key={m}
                type="button"
                onClick={() => {
                  setMode(m)
                  setError('')
                }}
                className={`rounded-lg py-2 text-sm font-medium transition ${
                  mode === m ? 'bg-white text-slate-900 shadow-sm dark:bg-slate-700 dark:text-white' : 'text-slate-500 dark:text-slate-400'
                }`}
              >
                {m === 'login' ? 'Вход' : 'Регистрация'}
              </button>
            ))}
          </div>

          <form onSubmit={submit} className="mt-6 space-y-4">
            {mode === 'register' && (
              <input className={inputCls} placeholder="Имя и фамилия" autoComplete="name" value={name} onChange={(e) => setName(e.target.value)} required minLength={2} />
            )}
            <input className={inputCls} type="email" placeholder="Email" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
            <input
              className={inputCls}
              type="password"
              placeholder={mode === 'register' ? 'Пароль (минимум 6 символов)' : 'Пароль'}
              autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              minLength={mode === 'register' ? 6 : 1}
            />
            {error && <p className="rounded-lg bg-rose-50 px-3 py-2 text-sm text-rose-700 dark:bg-rose-500/10 dark:text-rose-300">{error}</p>}
            <button type="submit" className={`${btn.primary} w-full`} disabled={busy}>
              {busy ? 'Подождите…' : mode === 'login' ? 'Войти' : 'Зарегистрироваться'}
            </button>
          </form>

          {mode === 'login' && (
            <div className="mt-6 rounded-xl border border-dashed border-slate-300 p-3 text-xs text-slate-500 dark:border-slate-700 dark:text-slate-400">
              Демо-доступ: <b className="text-slate-700 dark:text-slate-200">demo@teamtasks.ru</b> / <b className="text-slate-700 dark:text-slate-200">demo123</b>
              <button
                type="button"
                className="ml-2 font-semibold text-indigo-600 hover:underline dark:text-indigo-400"
                onClick={() => {
                  setEmail('demo@teamtasks.ru')
                  setPassword('demo123')
                }}
              >
                Подставить
              </button>
            </div>
          )}
        </div>
      </main>
    </div>
  )
}
