import { Check } from 'lucide-react'

export function Logo({ light }: { light?: boolean }) {
  return (
    <div className="relative flex items-center gap-2.5">
      <span className={`flex size-9 items-center justify-center rounded-xl ${light ? 'bg-white text-indigo-600' : 'bg-indigo-600 text-white'} shadow-sm`}>
        <Check className="size-5" strokeWidth={3} />
      </span>
      <span className={`text-lg font-bold tracking-tight ${light ? 'text-white' : ''}`}>TeamTasks</span>
    </div>
  )
}
