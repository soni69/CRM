export function initials(name: string | null | undefined) {
  if (!name) return '?'
  return name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0]!.toUpperCase())
    .join('')
}

const AVATAR_COLORS = [
  'bg-indigo-500', 'bg-violet-500', 'bg-pink-500', 'bg-rose-500', 'bg-orange-500',
  'bg-teal-500', 'bg-cyan-600', 'bg-emerald-600', 'bg-blue-500', 'bg-fuchsia-500',
]

export function avatarColor(id: number | null | undefined) {
  if (id == null) return 'bg-slate-300 dark:bg-slate-700'
  return AVATAR_COLORS[id % AVATAR_COLORS.length]
}

export function formatDue(date: string | null) {
  if (!date) return null
  const d = new Date(date + 'T00:00:00')
  const today = new Date()
  today.setHours(0, 0, 0, 0)
  const diff = Math.round((d.getTime() - today.getTime()) / 86400000)
  const label =
    diff === 0
      ? 'Сегодня'
      : diff === 1
        ? 'Завтра'
        : diff === -1
          ? 'Вчера'
          : d.toLocaleDateString('ru-RU', { day: 'numeric', month: 'short', year: d.getFullYear() !== today.getFullYear() ? 'numeric' : undefined })
  return { label, overdue: diff < 0, soon: diff >= 0 && diff <= 2 }
}

export function formatDateTime(value: string) {
  return new Date(value).toLocaleString('ru-RU', {
    day: 'numeric',
    month: 'short',
    hour: '2-digit',
    minute: '2-digit',
  })
}
