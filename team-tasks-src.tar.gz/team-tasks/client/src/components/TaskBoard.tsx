import { useCallback, useEffect, useMemo, useState } from 'react'
import { Columns3, List, LogOut, Moon, Plus, Search, Sun, X, ClipboardList } from 'lucide-react'
import { api, type TaskQuery } from '../lib/api'
import { STATUSES, type Status, type Task, type TaskInput, type User } from '../lib/types'
import { Avatar } from './Avatar'
import { Logo } from './Logo'
import { TaskCard } from './TaskCard'
import { TaskModal } from './TaskModal'
import { ConfirmDialog } from './ConfirmDialog'
import { btn, inputCls } from './Modal'
import { useToast } from './Toast'
import { useTheme } from '../lib/useTheme'

type View = 'board' | 'list'
interface Filters extends Required<TaskQuery> {}

function readFilters(): Filters {
  const p = new URLSearchParams(location.search)
  return { q: p.get('q') ?? '', status: p.get('status') ?? '', assignee: p.get('assignee') ?? '', sort: p.get('sort') ?? 'updated' }
}

function writeFilters(f: Filters) {
  const p = new URLSearchParams()
  if (f.q) p.set('q', f.q)
  if (f.status) p.set('status', f.status)
  if (f.assignee) p.set('assignee', f.assignee)
  if (f.sort && f.sort !== 'updated') p.set('sort', f.sort)
  const qs = p.toString()
  history.replaceState(null, '', qs ? `?${qs}` : location.pathname)
}

export function TaskBoard({ user, onLogout }: { user: User; onLogout: () => void }) {
  const toast = useToast()
  const { theme, toggle } = useTheme()
  const [tasks, setTasks] = useState<Task[]>([])
  const [users, setUsers] = useState<User[]>([])
  const [loading, setLoading] = useState(true)
  const [filters, setFilters] = useState<Filters>(readFilters)
  const [search, setSearch] = useState(filters.q)
  const [view, setView] = useState<View>(() => (localStorage.getItem('view') as View) || 'board')
  const [editing, setEditing] = useState<{ task: Task | null; status?: Status } | null>(null)
  const [deleting, setDeleting] = useState<Task | null>(null)
  const [dragOver, setDragOver] = useState<Status | null>(null)

  const setFilter = (patch: Partial<Filters>) => setFilters((f) => ({ ...f, ...patch }))

  useEffect(() => {
    const t = setTimeout(() => setFilter({ q: search.trim() }), 250)
    return () => clearTimeout(t)
  }, [search])

  useEffect(() => writeFilters(filters), [filters])
  useEffect(() => localStorage.setItem('view', view), [view])

  const load = useCallback(async () => {
    try {
      const { tasks } = await api.tasks({ q: filters.q, assignee: filters.assignee, sort: filters.sort })
      setTasks(tasks)
    } catch (err) {
      toast(err instanceof Error ? err.message : 'Не удалось загрузить задачи', 'error')
    } finally {
      setLoading(false)
    }
  }, [filters.q, filters.assignee, filters.sort, toast])

  useEffect(() => {
    load()
  }, [load])

  useEffect(() => {
    api.users().then(({ users }) => setUsers(users)).catch(() => {})
  }, [])

  const counts = useMemo(() => {
    const c: Record<Status, number> = { new: 0, in_progress: 0, done: 0 }
    tasks.forEach((t) => c[t.status]++)
    return c
  }, [tasks])

  const visible = filters.status ? tasks.filter((t) => t.status === filters.status) : tasks
  const hasFilters = !!(filters.q || filters.status || filters.assignee)

  const saveTask = async (input: TaskInput) => {
    if (editing?.task) {
      await api.updateTask(editing.task.id, input)
      toast('Задача обновлена')
    } else {
      await api.createTask(input)
      toast('Задача создана')
    }
    setEditing(null)
    load()
  }

  const changeStatus = async (task: Task, status: Status) => {
    setTasks((prev) => prev.map((t) => (t.id === task.id ? { ...t, status } : t)))
    try {
      await api.updateTask(task.id, { status })
      toast(`Статус: ${STATUSES.find((s) => s.value === status)!.label}`)
      load()
    } catch (err) {
      toast(err instanceof Error ? err.message : 'Ошибка', 'error')
      load()
    }
  }

  const confirmDelete = async () => {
    if (!deleting) return
    try {
      await api.deleteTask(deleting.id)
      setTasks((prev) => prev.filter((t) => t.id !== deleting.id))
      toast('Задача удалена')
      setDeleting(null)
      setEditing(null)
    } catch (err) {
      toast(err instanceof Error ? err.message : 'Ошибка', 'error')
    }
  }

  const card = (t: Task, draggable = false) => (
    <TaskCard
      key={t.id}
      task={t}
      draggable={draggable}
      onOpen={() => setEditing({ task: t })}
      onDelete={() => setDeleting(t)}
      onStatus={(s) => changeStatus(t, s)}
    />
  )

  const columns = filters.status ? STATUSES.filter((s) => s.value === filters.status) : STATUSES

  return (
    <div className="min-h-dvh pb-24 sm:pb-10">
      <header className="sticky top-0 z-30 border-b border-slate-200/70 bg-white/80 backdrop-blur-lg dark:border-slate-800 dark:bg-slate-950/80">
        <div className="mx-auto flex h-16 max-w-7xl items-center gap-3 px-4 sm:px-6">
          <Logo />
          <div className="ml-auto flex items-center gap-1 sm:gap-2">
            <button onClick={toggle} className="rounded-xl p-2.5 text-slate-500 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800" aria-label="Сменить тему">
              {theme === 'dark' ? <Sun className="size-5" /> : <Moon className="size-5" />}
            </button>
            <div className="flex items-center gap-2 rounded-xl py-1 pr-1 pl-2 sm:pl-3">
              <div className="hidden text-right sm:block">
                <div className="text-sm leading-tight font-semibold">{user.name}</div>
                <div className="text-xs leading-tight text-slate-500 dark:text-slate-400">{user.email}</div>
              </div>
              <Avatar id={user.id} name={user.name} />
            </div>
            <button onClick={onLogout} className="rounded-xl p-2.5 text-slate-500 hover:bg-slate-100 hover:text-rose-600 dark:text-slate-400 dark:hover:bg-slate-800" aria-label="Выйти" title="Выйти">
              <LogOut className="size-5" />
            </button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-4 pt-6 sm:px-6">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold tracking-tight sm:text-3xl">Задачи команды</h1>
            <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
              {tasks.length} {plural(tasks.length, ['задача', 'задачи', 'задач'])} · {users.length} {plural(users.length, ['участник', 'участника', 'участников'])}
            </p>
          </div>
          <div className="hidden sm:block">
            <button onClick={() => setEditing({ task: null })} className={btn.primary}>
              <Plus className="size-4" /> Новая задача
            </button>
          </div>
        </div>

        <div className="mt-5 grid grid-cols-3 gap-2 sm:gap-4">
          {STATUSES.map((s) => {
            const active = filters.status === s.value
            return (
              <button
                key={s.value}
                onClick={() => setFilter({ status: active ? '' : s.value })}
                className={`rounded-2xl bg-white p-3 text-left ring-1 transition sm:p-4 dark:bg-slate-900 ${
                  active ? 'ring-2 ring-indigo-500' : 'ring-slate-200/70 hover:ring-slate-300 dark:ring-slate-800 dark:hover:ring-slate-700'
                }`}
              >
                <div className="flex items-center gap-1.5 text-xs font-medium text-slate-500 sm:text-sm dark:text-slate-400">
                  <span className={`size-2 rounded-full ${s.dot}`} />
                  <span className="truncate">{s.label}</span>
                </div>
                <div className="mt-1 text-2xl font-bold sm:text-3xl">{counts[s.value]}</div>
              </button>
            )
          })}
        </div>

        <div className="mt-5 flex flex-col gap-2 sm:flex-row sm:items-center">
          <div className="relative flex-1">
            <Search className="pointer-events-none absolute top-1/2 left-3.5 size-4 -translate-y-1/2 text-slate-400" />
            <input className={`${inputCls} pr-9 pl-10`} placeholder="Поиск по названию и описанию…" value={search} onChange={(e) => setSearch(e.target.value)} />
            {search && (
              <button onClick={() => setSearch('')} className="absolute top-1/2 right-2 -translate-y-1/2 rounded-lg p-1 text-slate-400 hover:text-slate-600" aria-label="Очистить поиск">
                <X className="size-4" />
              </button>
            )}
          </div>
          <div className="grid grid-cols-2 gap-2 sm:flex">
            <select className={`${inputCls} sm:w-44`} value={filters.status} onChange={(e) => setFilter({ status: e.target.value })} aria-label="Статус">
              <option value="">Все статусы</option>
              {STATUSES.map((s) => (
                <option key={s.value} value={s.value}>
                  {s.label}
                </option>
              ))}
            </select>
            <select className={`${inputCls} sm:w-48`} value={filters.assignee} onChange={(e) => setFilter({ assignee: e.target.value })} aria-label="Ответственный">
              <option value="">Все ответственные</option>
              <option value="me">Мои задачи</option>
              <option value="none">Без ответственного</option>
              {users.map((u) => (
                <option key={u.id} value={u.id}>
                  {u.name}
                </option>
              ))}
            </select>
            <select className={`${inputCls} sm:w-44`} value={filters.sort} onChange={(e) => setFilter({ sort: e.target.value })} aria-label="Сортировка">
              <option value="updated">Недавно изменённые</option>
              <option value="created">Новые сначала</option>
              <option value="due">По сроку</option>
              <option value="priority">По приоритету</option>
            </select>
            <div className="flex rounded-xl bg-slate-100 p-1 dark:bg-slate-800">
              {(
                [
                  ['board', Columns3, 'Доска'],
                  ['list', List, 'Список'],
                ] as const
              ).map(([v, Icon, label]) => (
                <button
                  key={v}
                  onClick={() => setView(v)}
                  title={label}
                  className={`flex flex-1 items-center justify-center gap-1.5 rounded-lg px-3 py-1.5 text-sm font-medium transition ${
                    view === v ? 'bg-white text-slate-900 shadow-sm dark:bg-slate-700 dark:text-white' : 'text-slate-500 dark:text-slate-400'
                  }`}
                >
                  <Icon className="size-4" />
                  <span className="lg:inline sm:hidden">{label}</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {hasFilters && (
          <div className="mt-3 flex items-center gap-2 text-sm text-slate-500 dark:text-slate-400">
            Найдено: <b className="text-slate-700 dark:text-slate-200">{visible.length}</b>
            <button
              onClick={() => {
                setSearch('')
                setFilters((f) => ({ ...f, q: '', status: '', assignee: '' }))
              }}
              className="font-medium text-indigo-600 hover:underline dark:text-indigo-400"
            >
              Сбросить фильтры
            </button>
          </div>
        )}

        <section className="mt-6">
          {loading ? (
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {[0, 1, 2].map((i) => (
                <div key={i} className="h-32 animate-pulse rounded-2xl bg-slate-200/60 dark:bg-slate-800/60" />
              ))}
            </div>
          ) : visible.length === 0 && view === 'list' ? (
            <EmptyState filtered={hasFilters} onCreate={() => setEditing({ task: null })} />
          ) : view === 'list' ? (
            <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">{visible.map((t) => card(t))}</div>
          ) : tasks.length === 0 && !hasFilters ? (
            <EmptyState filtered={false} onCreate={() => setEditing({ task: null })} />
          ) : (
            <div className={`-mx-4 flex snap-x snap-mandatory gap-4 overflow-x-auto px-4 pb-4 sm:mx-0 sm:px-0 md:grid md:overflow-visible ${columns.length === 1 ? 'md:grid-cols-1' : 'md:grid-cols-3'}`}>
              {columns.map((s) => {
                const items = visible.filter((t) => t.status === s.value)
                return (
                  <div
                    key={s.value}
                    onDragOver={(e) => {
                      e.preventDefault()
                      setDragOver(s.value)
                    }}
                    onDragLeave={() => setDragOver(null)}
                    onDrop={(e) => {
                      e.preventDefault()
                      setDragOver(null)
                      const t = tasks.find((x) => x.id === Number(e.dataTransfer.getData('text/plain')))
                      if (t && t.status !== s.value) changeStatus(t, s.value)
                    }}
                    className={`flex w-[85%] shrink-0 snap-center flex-col rounded-2xl bg-slate-100/70 p-3 transition md:w-auto dark:bg-slate-900/50 ${
                      dragOver === s.value ? 'bg-indigo-50 ring-2 ring-indigo-400 ring-dashed dark:bg-indigo-500/10' : ''
                    }`}
                  >
                    <div className="mb-3 flex items-center justify-between px-1">
                      <div className="flex items-center gap-2 text-sm font-semibold">
                        <span className={`size-2.5 rounded-full ${s.dot}`} />
                        {s.label}
                        <span className="rounded-full bg-white px-2 py-0.5 text-xs font-medium text-slate-500 dark:bg-slate-800 dark:text-slate-400">{items.length}</span>
                      </div>
                      <button
                        onClick={() => setEditing({ task: null, status: s.value })}
                        className="rounded-lg p-1 text-slate-400 hover:bg-white hover:text-indigo-600 dark:hover:bg-slate-800"
                        aria-label={`Добавить задачу в «${s.label}»`}
                      >
                        <Plus className="size-4" />
                      </button>
                    </div>
                    <div className="flex min-h-24 flex-1 flex-col gap-3">
                      {items.map((t) => card(t, true))}
                      {items.length === 0 && (
                        <div className="flex flex-1 items-center justify-center rounded-xl border-2 border-dashed border-slate-200 py-8 text-center text-xs text-slate-400 dark:border-slate-800">
                          Нет задач
                        </div>
                      )}
                    </div>
                  </div>
                )
              })}
            </div>
          )}
        </section>
      </main>

      <button
        onClick={() => setEditing({ task: null })}
        className="fixed right-5 bottom-[max(1.25rem,env(safe-area-inset-bottom))] z-40 flex size-14 items-center justify-center rounded-2xl bg-indigo-600 text-white shadow-xl shadow-indigo-600/30 transition active:scale-95 sm:hidden"
        aria-label="Новая задача"
      >
        <Plus className="size-6" />
      </button>

      {editing && (
        <TaskModal
          task={editing.task}
          defaultStatus={editing.status}
          users={users}
          currentUser={user}
          onSave={saveTask}
          onDelete={editing.task ? () => setDeleting(editing.task) : undefined}
          onClose={() => setEditing(null)}
        />
      )}
      {deleting && (
        <ConfirmDialog
          title="Удалить задачу?"
          text={`Задача «${deleting.title}» будет удалена без возможности восстановления.`}
          confirmLabel="Удалить"
          onConfirm={confirmDelete}
          onClose={() => setDeleting(null)}
        />
      )}
    </div>
  )
}

function EmptyState({ filtered, onCreate }: { filtered: boolean; onCreate: () => void }) {
  return (
    <div className="flex flex-col items-center rounded-2xl border-2 border-dashed border-slate-200 px-6 py-16 text-center dark:border-slate-800">
      <span className="rounded-2xl bg-indigo-50 p-4 text-indigo-600 dark:bg-indigo-500/10 dark:text-indigo-400">
        <ClipboardList className="size-8" />
      </span>
      <h3 className="mt-4 font-semibold">{filtered ? 'Ничего не найдено' : 'Задач пока нет'}</h3>
      <p className="mt-1 max-w-xs text-sm text-slate-500 dark:text-slate-400">
        {filtered ? 'Попробуйте изменить запрос или сбросить фильтры' : 'Создайте первую задачу и назначьте ответственного'}
      </p>
      {!filtered && (
        <button onClick={onCreate} className={`${btn.primary} mt-5`}>
          <Plus className="size-4" /> Создать задачу
        </button>
      )}
    </div>
  )
}

function plural(n: number, forms: [string, string, string]) {
  const m10 = n % 10
  const m100 = n % 100
  if (m10 === 1 && m100 !== 11) return forms[0]
  if (m10 >= 2 && m10 <= 4 && (m100 < 12 || m100 > 14)) return forms[1]
  return forms[2]
}
