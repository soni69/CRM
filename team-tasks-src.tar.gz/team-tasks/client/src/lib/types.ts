export type Status = 'new' | 'in_progress' | 'done'
export type Priority = 'low' | 'medium' | 'high'

export interface User {
  id: number
  name: string
  email: string
}

export interface Task {
  id: number
  title: string
  description: string
  status: Status
  priority: Priority
  due_date: string | null
  assignee_id: number | null
  assignee_name: string | null
  creator_id: number
  creator_name: string | null
  created_at: string
  updated_at: string
}

export type TaskInput = Pick<Task, 'title' | 'description' | 'status' | 'priority' | 'due_date' | 'assignee_id'>

export const STATUSES: { value: Status; label: string; dot: string; badge: string }[] = [
  {
    value: 'new',
    label: 'Новая',
    dot: 'bg-sky-500',
    badge: 'bg-sky-50 text-sky-700 ring-sky-600/20 dark:bg-sky-500/10 dark:text-sky-300 dark:ring-sky-400/30',
  },
  {
    value: 'in_progress',
    label: 'В работе',
    dot: 'bg-amber-500',
    badge: 'bg-amber-50 text-amber-700 ring-amber-600/20 dark:bg-amber-500/10 dark:text-amber-300 dark:ring-amber-400/30',
  },
  {
    value: 'done',
    label: 'Завершена',
    dot: 'bg-emerald-500',
    badge: 'bg-emerald-50 text-emerald-700 ring-emerald-600/20 dark:bg-emerald-500/10 dark:text-emerald-300 dark:ring-emerald-400/30',
  },
]

export const PRIORITIES: { value: Priority; label: string; className: string }[] = [
  { value: 'low', label: 'Низкий', className: 'text-slate-500 dark:text-slate-400' },
  { value: 'medium', label: 'Средний', className: 'text-indigo-600 dark:text-indigo-400' },
  { value: 'high', label: 'Высокий', className: 'text-rose-600 dark:text-rose-400' },
]

export const statusMeta = (s: Status) => STATUSES.find((x) => x.value === s)!
export const priorityMeta = (p: Priority) => PRIORITIES.find((x) => x.value === p)!
