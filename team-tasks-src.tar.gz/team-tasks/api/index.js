import { app, handleErrors } from '../server/src/app.js';

handleErrors(app);

export default app;
