import type { Task, TaskInput, User } from './types'

export class ApiError extends Error {
  status: number
  constructor(message: string, status: number) {
    super(message)
    this.status = status
  }
}

async function request<T>(url: string, options: RequestInit = {}): Promise<T> {
  const res = await fetch(url, {
    credentials: 'same-origin',
    ...options,
    headers: { 'Content-Type': 'application/json', ...options.headers },
  })
  const data = await res.json().catch(() => ({}))
  if (!res.ok) throw new ApiError(data.error || 'Ошибка сети', res.status)
  return data as T
}

export interface TaskQuery {
  q?: string
  status?: string
  assignee?: string
  sort?: string
}

export const api = {
  me: () => request<{ user: User }>('/api/auth/me'),
  login: (email: string, password: string) =>
    request<{ user: User }>('/api/auth/login', { method: 'POST', body: JSON.stringify({ email, password }) }),
  register: (name: string, email: string, password: string) =>
    request<{ user: User }>('/api/auth/register', { method: 'POST', body: JSON.stringify({ name, email, password }) }),
  logout: () => request<{ ok: true }>('/api/auth/logout', { method: 'POST' }),
  users: () => request<{ users: User[] }>('/api/users'),
  tasks: (query: TaskQuery) => {
    const params = new URLSearchParams(Object.entries(query).filter(([, v]) => v) as [string, string][])
    return request<{ tasks: Task[] }>(`/api/tasks?${params}`)
  },
  createTask: (input: TaskInput) => request<{ task: Task }>('/api/tasks', { method: 'POST', body: JSON.stringify(input) }),
  updateTask: (id: number, patch: Partial<TaskInput>) =>
    request<{ task: Task }>(`/api/tasks/${id}`, { method: 'PATCH', body: JSON.stringify(patch) }),
  deleteTask: (id: number) => request<{ ok: true }>(`/api/tasks/${id}`, { method: 'DELETE' }),
}
