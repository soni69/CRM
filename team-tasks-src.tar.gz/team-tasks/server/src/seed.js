import bcrypt from 'bcryptjs';
import crypto from 'node:crypto';
import { pool } from './db.js';

const DEMO_USERS = [
  ['Демо Пользователь', 'demo@teamtasks.ru', 'demo123'],
  ['Анна Смирнова', 'anna@teamtasks.ru'],
  ['Игорь Петров', 'igor@teamtasks.ru'],
  ['Мария Козлова', 'maria@teamtasks.ru'],
];

const day = (offset) => {
  const d = new Date();
  d.setDate(d.getDate() + offset);
  return d.toISOString().slice(0, 10);
};

const DEMO_TASKS = [
  ['Подготовить макеты главной страницы', 'Desktop и mobile версии, согласовать с заказчиком', 'in_progress', 'high', 2, 1],
  ['Настроить CI/CD для проекта', 'GitHub Actions: линтер, тесты, деплой на staging', 'new', 'medium', 3, 5],
  ['Провести интервью с пользователями', '5 респондентов, сценарий в Notion', 'new', 'high', 4, 1],
  ['Исправить баг с авторизацией в Safari', 'Cookie не сохраняется после редиректа', 'in_progress', 'high', 3, -1],
  ['Написать документацию по API', '', 'new', 'low', null, 10],
  ['Обновить зависимости фронтенда', 'React, Vite, Tailwind до последних версий', 'done', 'medium', 3, -3],
  ['Созвон с командой по итогам спринта', 'Ретроспектива + планирование следующего спринта', 'done', 'medium', 1, -2],
  ['Оптимизировать загрузку изображений', 'WebP + lazy loading', 'in_progress', 'low', 2, 7],
];

export async function seedDemo() {
  if (process.env.SEED_DEMO === 'false') return;
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query('LOCK TABLE users IN EXCLUSIVE MODE');
    const { rows } = await client.query('SELECT COUNT(*)::int AS n FROM users');
    if (rows[0].n > 0) {
      await client.query('ROLLBACK');
      return;
    }
    const ids = [];
    for (const [name, email, password] of DEMO_USERS) {
      const hash = bcrypt.hashSync(password || crypto.randomUUID(), 10);
      const r = await client.query('INSERT INTO users (name, email, password_hash) VALUES ($1, $2, $3) RETURNING id', [name, email, hash]);
      ids.push(r.rows[0].id);
    }
    for (const [title, desc, status, priority, assignee, due] of DEMO_TASKS) {
      await client.query(
        `INSERT INTO tasks (title, description, status, priority, assignee_id, creator_id, due_date)
         VALUES ($1, $2, $3, $4, $5, $6, $7)`,
        [title, desc, status, priority, assignee ? ids[assignee - 1] : null, ids[0], due == null ? null : day(due)],
      );
    }
    await client.query('COMMIT');
    console.log('Demo data created: demo@teamtasks.ru / demo123');
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {});
    throw err;
  } finally {
    client.release();
  }
}
