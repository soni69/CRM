import { useState, type FormEvent } from 'react'
import { Trash2 } from 'lucide-react'
import { Modal, btn, inputCls } from './Modal'
import { PRIORITIES, STATUSES, type Status, type Task, type TaskInput, type User } from '../lib/types'
import { formatDateTime } from '../lib/format'

interface Props {
  task: Task | null
  defaultStatus?: Status
  users: User[]
  currentUser: User
  onSave: (input: TaskInput) => Promise<void>
  onDelete?: () => void
  onClose: () => void
}

export function TaskModal({ task, defaultStatus = 'new', users, currentUser, onSave, onDelete, onClose }: Props) {
  const [form, setForm] = useState<TaskInput>({
    title: task?.title ?? '',
    description: task?.description ?? '',
    status: task?.status ?? defaultStatus,
    priority: task?.priority ?? 'medium',
    due_date: task?.due_date ?? null,
    assignee_id: task ? task.assignee_id : currentUser.id,
  })
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)
  const set = <K extends keyof TaskInput>(k: K, v: TaskInput[K]) => setForm((f) => ({ ...f, [k]: v }))

  const submit = async (e: FormEvent) => {
    e.preventDefault()
    if (!form.title.trim()) return setError('Введите название задачи')
    setBusy(true)
    setError('')
    try {
      await onSave({ ...form, title: form.title.trim() })
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Не удалось сохранить')
      setBusy(false)
    }
  }

  return (
    <Modal
      title={task ? 'Редактирование задачи' : 'Новая задача'}
      onClose={onClose}
      footer={
        <>
          {task && onDelete && (
            <button type="button" onClick={onDelete} className={`${btn.secondary} mr-auto !text-rose-600`}>
              <Trash2 className="size-4" />
              <span className="hidden sm:inline">Удалить</span>
            </button>
          )}
          <button type="button" className={btn.secondary} onClick={onClose}>
            Отмена
          </button>
          <button type="submit" form="task-form" className={btn.primary} disabled={busy}>
            {task ? 'Сохранить' : 'Создать'}
          </button>
        </>
      }
    >
      <form id="task-form" onSubmit={submit} className="space-y-4">
        <Field label="Название">
          <input
            autoFocus
            className={inputCls}
            value={form.title}
            maxLength={200}
            placeholder="Например, подготовить отчёт"
            onChange={(e) => set('title', e.target.value)}
          />
        </Field>
        <Field label="Описание">
          <textarea
            className={`${inputCls} min-h-24 resize-y`}
            value={form.description}
            maxLength={5000}
            placeholder="Детали, ссылки, критерии готовности…"
            onChange={(e) => set('description', e.target.value)}
          />
        </Field>

        <Field label="Статус">
          <div className="grid grid-cols-3 gap-1 rounded-xl bg-slate-100 p-1 dark:bg-slate-800">
            {STATUSES.map((s) => (
              <button
                key={s.value}
                type="button"
                onClick={() => set('status', s.value)}
                className={`flex items-center justify-center gap-1.5 rounded-lg px-2 py-2 text-xs font-medium transition sm:text-sm ${
                  form.status === s.value
                    ? 'bg-white text-slate-900 shadow-sm dark:bg-slate-700 dark:text-white'
                    : 'text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200'
                }`}
              >
                <span className={`size-2 rounded-full ${s.dot}`} />
                {s.label}
              </button>
            ))}
          </div>
        </Field>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <Field label="Ответственный">
            <select
              className={inputCls}
              value={form.assignee_id ?? ''}
              onChange={(e) => set('assignee_id', e.target.value ? Number(e.target.value) : null)}
            >
              <option value="">Не назначен</option>
              {users.map((u) => (
                <option key={u.id} value={u.id}>
                  {u.name}
                  {u.id === currentUser.id ? ' (вы)' : ''}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Приоритет">
            <select className={inputCls} value={form.priority} onChange={(e) => set('priority', e.target.value as TaskInput['priority'])}>
              {PRIORITIES.map((p) => (
                <option key={p.value} value={p.value}>
                  {p.label}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Срок">
            <input type="date" className={inputCls} value={form.due_date ?? ''} onChange={(e) => set('due_date', e.target.value || null)} />
          </Field>
        </div>

        {error && <p className="rounded-lg bg-rose-50 px-3 py-2 text-sm text-rose-700 dark:bg-rose-500/10 dark:text-rose-300">{error}</p>}

        {task && (
          <p className="text-xs text-slate-400">
            Создал(а) {task.creator_name ?? '—'} · {formatDateTime(task.created_at)} · изменено {formatDateTime(task.updated_at)}
          </p>
        )}
      </form>
    </Modal>
  )
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-medium tracking-wide text-slate-500 uppercase dark:text-slate-400">{label}</span>
      {children}
    </label>
  )
}
