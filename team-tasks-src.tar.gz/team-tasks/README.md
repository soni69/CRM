# TeamTasks — управление задачами команды

Веб-приложение для командной работы с задачами: создание, редактирование, удаление, назначение ответственных, статусы, поиск и фильтры. Адаптивный интерфейс для компьютера и телефона, светлая и тёмная темы.

![Доска задач](docs/desktop-board.png)

| Вход | Мобильная версия | Редактирование |
|---|---|---|
| ![](docs/desktop-login.png) | ![](docs/mobile-board.png) | ![](docs/mobile-modal.png) |

## Возможности

- **Авторизация** — регистрация и вход по email и паролю (bcrypt + JWT в httpOnly-cookie, сессия 30 дней).
- **Задачи** — создание, редактирование, удаление (с подтверждением). Поля: название, описание, статус, приоритет, срок, ответственный.
- **Ответственный** — любой зарегистрированный участник команды.
- **Статусы** «Новая», «В работе», «Завершена». Сменить статус можно из меню на карточке, перетаскиванием на канбан-доске или в форме задачи.
- **Поиск и фильтрация** — поиск по названию и описанию, фильтры по статусу и ответственному («Мои», «Без ответственного», конкретный участник), сортировка по дате изменения/создания, сроку, приоритету.
- **Сохранение данных** — всё хранится в БД на сервере; фильтры сохраняются в URL, вид (доска/список) и тема — в localStorage.
- **Два вида** — канбан-доска и список. Просроченные задачи и задачи с близким сроком подсвечиваются.

Демо-аккаунт (создаётся при первом запуске): `demo@teamtasks.ru` / `demo123`.

## Стек

| Часть | Технологии |
|---|---|
| Фронтенд | React 19, TypeScript, Vite, Tailwind CSS 4, lucide-react |
| Бэкенд | Node.js, Express 5, zod, bcryptjs, jsonwebtoken |
| База данных | PostgreSQL (Neon на Vercel) |
| Деплой | Vercel (статика + serverless-функция API) или Docker Compose + Caddy на VPS |

```
client/   — SPA на React (src/components, src/lib)
api/      — точка входа serverless-функции Vercel
server/   — REST API на Express
  src/app.js    — маршруты API
  src/db.js     — подключение к Postgres и схема БД (создаётся автоматически)
  src/auth.js   — JWT-сессии
  src/seed.js   — демо-данные
  src/index.js  — обычный HTTP-сервер (локально / Docker), раздаёт и фронтенд
```

### API

| Метод | Путь | Описание |
|---|---|---|
| POST | `/api/auth/register` | регистрация |
| POST | `/api/auth/login` | вход |
| POST | `/api/auth/logout` | выход |
| GET | `/api/auth/me` | текущий пользователь |
| GET | `/api/users` | участники команды |
| GET | `/api/tasks?q=&status=&assignee=&sort=` | список задач с поиском и фильтрами |
| POST | `/api/tasks` | создать задачу |
| PATCH | `/api/tasks/:id` | изменить задачу (в т.ч. статус) |
| DELETE | `/api/tasks/:id` | удалить задачу |

## Локальный запуск

Требуется Node.js 20+ и PostgreSQL (например, `docker run -d -p 5432:5432 -e POSTGRES_PASSWORD=pg -e POSTGRES_DB=teamtasks postgres:17-alpine`).

```bash
cp .env.example .env        # укажите DATABASE_URL и JWT_SECRET
npm run install:all
npm run dev:server          # API на http://localhost:3000
npm run dev:client          # фронтенд на http://localhost:5173
```

## Деплой на Vercel

1. Импортируйте репозиторий в Vercel (настройки сборки берутся из `vercel.json`).
2. Storage → Create Database → **Neon (Postgres)** и подключите к проекту — переменная `DATABASE_URL` добавится автоматически.
3. Settings → Environment Variables: добавьте `JWT_SECRET` (`openssl rand -hex 32`).
4. Redeploy. Таблицы и демо-данные создадутся при первом запросе.

## Деплой на VPS (Docker)

```bash
git clone <repo-url> team-tasks && cd team-tasks
cp .env.example .env
sed -i "s/^JWT_SECRET=.*/JWT_SECRET=$(openssl rand -hex 32)/; s/^POSTGRES_PASSWORD=.*/POSTGRES_PASSWORD=$(openssl rand -hex 16)/" .env
# при наличии домена: SITE_ADDRESS=tasks.example.com (HTTPS выпустится автоматически)
docker compose up -d --build
```

Данные хранятся в Docker-томе `db-data` и переживают перезапуски и обновления.
Обновление: `git pull && docker compose up -d --build`.
